# -*- coding: utf-8 -*-
"""
Created on Fri Aug 13 11:58:50 2021

@author: user
"""
'''
try: 
    from BeautifulSoup import BeautifulSoup
except ImportError:
    from bs4 import BeautifulSoup
html = #the HTML code you've written above
parsed_html = BeautifulSoup(html)
print(parsed_html.body.find('div', attrs={'class':'container'}).text)

==============================================

#pandas.read_html(html_string_or_url)



=====================================


import pandas as pd

tables = pd.read_html('report.html')
print('Tables found:', len(tables))
df1 = tables[0]  # Save first table in variable df1
df2 = tables[1]  # Saving next table in variable df2

print('First Table')
print(df1)
print('Another Table')
print(df2)


df1.to_excel('df1.xlsx')

df2.to_excel('df2.xlsx')
===============================================
'''
import pandas as pd
tables = pd.read_html('report.html')
df2 = tables[1]  
print(df2)

df1=tables[0]
df1.to_excel('df1.xlsx')
df2.to_excel('df2.xlsx')