# -*- coding: utf-8 -*-
"""
Created on Wed Aug 18 11:58:23 2021

@author: user
"""

#------------------get info of latest builds 
from jenkinsapi.jenkins import Jenkins

def getSCMInfroFromLatestGoodBuild(url, jobName, username=None, password=None):
    J = Jenkins(url, username, password)
    job = J[jobName]
    lgb = job.get_last_good_build()
    return lgb.get_revision()

if __name__ == '__main__':
    print getSCMInfroFromLatestGoodBuild('http://localhost:8080', 'fooJob')
#========================================================
#jenkins_url="https://myjenkins.com:8080"
jenkins_url='http://localhost:8080/'
jenkins_user="ashish.dondapati@gmail.com"

jenkins_pwd="111f7aba2d4517dcd587fbc98f62570ac8"

jenkins_url + /api/json

curl -X GET -s -u ${jenkins_user}:${jenkins_pwd} https://${jenkins_url}/api/json





import base64
import json

import requests



class APIClient:
    def __init__(self, base_url):
        self.user = ''
        self.password = ''
        if not base_url.endswith('/'):
            base_url += '/'
        self.__url = base_url + 'index.php?/api/v2/'
        self.status_code = None
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
 =========================================================================api send and get requests jenkis 
jenkins_url='http://localhost:8080/'
user="ashish.dondapati@gmail.com"
password="111f7aba2d4517dcd587fbc98f62570ac8"
auth = str(
    base64.b64encode(
        bytes('%s:%s' % (user, password), 'utf-8')
    ),
    'ascii'
).strip()
headers = {'Authorization': 'Basic ' + auth}

if method == 'POST':
    if uri[:14] == 'add_attachment':    # add_attachment API method
        files = {'attachment': (open(data, 'rb'))}
        response = requests.post(url, headers=headers, files=files)
        files['attachment'].close()
    else:
        headers['Content-Type'] = 'application/json'
        payload = bytes(json.dumps(data), 'utf-8')
        response = requests.post(url, headers=headers, data=payload)
else:
    headers['Content-Type'] = 'application/json'
    response = requests.get(url, headers=headers)

if response.status_code > 201:
    status_code = response.status_code
    try:
        error = response.json()
    except:     # response.content not formatted as JSON
        error = str(response.content)
    raise APIError('TestRail API returned HTTP %s (%s)' % (response.status_code, error))
else:
    if uri[:15] == 'get_attachment/':   # Expecting file, not JSON
        try:
            open(data, 'wb').write(response.content)
            return (data)
        except:
            return ("Error saving attachment.")
    else:
        try:
            return response.json()
        except: # Nothing to return
            return {}
        
        
        
        
   @@@@@@@@@@@@@@@@@@@@@@@@@@
https://www.linkedin.com/pulse/useful-jenkins-rest-apis-prudviraj-pentakota/     
        
        
        
        
        
        
        
        =========================================python jenkins
        https://python-jenkins.readthedocs.io/en/latest/examples.html
        https://python-jenkins.readthedocs.io/en/latest/api.html
        https://www.informaticsmatters.com/blog/2018/06/18/inspecting-jenkins-jobs-with-python.html
        https://www.youtube.com/watch?v=lJcJMyrhMV8
        
        ===================================================jenkinsapi
        https://jenkinsapi.readthedocs.io/en/latest/index.html
        
        
        
        https://pythonhosted.org/jenkinsapi/#sections
        https://www.jenkins.io/doc/book/using/remote-access-api/