# -*- coding: utf-8 -*-
"""
Created on Wed Aug 18 16:00:58 2021

@author: user
"""

from jenkinsapi.jenkins import Jenkins

def get_server_instance():
    jenkins_url = 'http://localhost:8080'
    server = Jenkins(jenkins_url, username = 'ashish_dondapati', password = 'ashish97')
    return server

"""Get job details of each job that is running on the Jenkins instance"""
def get_job_details():
    # Refer Example #1 for definition of function 'get_server_instance'
    server = get_server_instance()
    for job_name, job_instance in server.get_jobs():
        print('Job Name:%s' % (job_instance.name))
        print('Job Description:%s' % (job_instance.get_description()))
        print('Is Job running:%s' % (job_instance.is_running()))
        print('Is Job enabled:%s' % (job_instance.is_enabled()))
"""Disable a Jenkins job"""
def disable_job():
    # Refer Example #1 for definition of function 'get_server_instance'
    server = get_server_instance()
    job_name = 'nightly-build-job'
    if (server.has_job(job_name)):
        job_instance = server.get_job(job_name)
        job_instance.disable()
        print('Name:%s,Is Job Enabled ?:%s' % (job_name,job_instance.is_enabled()))

def get_plugin_details():
    # Refer Example #1 for definition of function 'get_server_instance'
    server = get_server_instance()
    for plugin in server.get_plugins().values():
        print("Short Name:%s" % (plugin.shortName))
        print("Long Name:%s" % (plugin.longName))
        print("Version:%s" % (plugin.version))
        print("URL:%s" % (plugin.url))
        print("Active:%s" % (plugin.active))
        print("Enabled:%s" % (plugin.enabled))
        
        


def getSCMInfroFromLatestGoodBuild(url, jobName, username=None, password=None):
    J = Jenkins(url, username, password)
    job = J[jobName]
    lgb = job.get_last_good_build()
    return lgb.get_revision()      
if __name__ == '__main__':
    print(get_server_instance().version)
    print(getSCMInfroFromLatestGoodBuild('http://localhost:8080', 'fooJob'))
    
    
    
    
    
    
    
   https://narenchejara.medium.com/trigger-jenkins-job-remotely-using-jenkins-api-20973618a493
   https://dzone.com/articles/triggering-cloudbees-jenkins-build-remotely-using
    
    
    
    
    
    
    