
import json
import requests
from config import STRATUS_DEVICE_SERVER_STACKS as SERVER_STACKS, PROXIES
from config import UCDE_SERVICES_SERVER_STACKS as UCDE_STACKS
# User Defined Exceptions
from exceptions.stratus_device_error import StratusDeviceError
from exceptions.stratus_device_http_error import StratusDeviceHTTPError


API_VERSION = 1


def fetch_ownership_id(stack='pie', user_access_token=None, device_id=None, use_proxy=False):

    headers = None

    data = None

    resp = None

    try:

        url = '{}/devices/v{}/ownerships/lookup'.format(SERVER_STACKS[stack]['stratus_device_uri'], API_VERSION)

        headers = {'Content-Type': 'application/json',
                   'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(user_access_token)}

        resp = requests.get(url, verify=False, params = {'deviceId': device_id},headers=headers, proxies=PROXIES if use_proxy else None)
        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise StratusDeviceHTTPError(http_error, headers, data, resp)
    except Exception as err:
        raise StratusDeviceError(err)
    else:
        body = json.loads(resp.text)
        ownership_id = body['ownershipId']
    return ownership_id


def unclaim_device(stack='pie', ownership_id=None, printer=None, user_access_token=None, use_proxy=False):

    headers = None

    data = None

    resp = None

    try:

        url = '{}/devices/v{}/ownerships/{}'.format(SERVER_STACKS[stack]['stratus_device_uri'],
                                                    API_VERSION, ownership_id)

        headers = {'Content-Type': 'application/json',
                   'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(user_access_token)}

        resp = requests.delete(url, verify=False, headers=headers, proxies=PROXIES if use_proxy else None)

        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise StratusDeviceHTTPError(http_error, headers, data, resp)
    except Exception as err:
        raise StratusDeviceError(err)
    else:
        return resp


def register_device_wfh(stack='stage', user_access_token=None, cloud_id=None, use_proxy=False,programname='ws-hp.com/wfh'):

    headers = None

    data = None

    resp = None

    payload=None

    device_program_info = {}
    try:
        url = '{}/v2/ecosystem/programmgtsvc/deviceprograminfos'.format(UCDE_STACKS[stack]['ucde_services_base_uri'], API_VERSION)

        headers = {'Content-Type': 'application/json',
                   'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(user_access_token)}

        payload.update({'cloudId': cloud_id, 'programName': programname})
        resp = requests.get(url, verify=False, headers=headers, data=payload, proxies=PROXIES if use_proxy else None)
        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise StratusDeviceHTTPError(http_error, headers, data, resp)
    except Exception as err:
        raise StratusDeviceError(err)
    else:
        if resp.status_code == 200:
            body = json.loads(resp.text)
            device_program_info["cloudId"] = body['cloudId']
            device_program_info["companyTenantId"] = body['companyTenantId']
            device_program_info["companyId"] = body['companyId']
            device_program_info["tenantId"] = body['tenantId']
    return device_program_info
