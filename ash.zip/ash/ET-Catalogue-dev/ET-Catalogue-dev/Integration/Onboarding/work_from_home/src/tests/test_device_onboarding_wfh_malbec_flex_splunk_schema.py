from tests.test_device_onboarding_wfh_malbec_param import Param
from services import splunk_service


class SplunkSchema(object):
    test_names = [
        "test_device_onboarding__01_04_wpp__createWFHPrinter",
        "test_device_onboarding__02_04_jam__registerDeviceInJAM",
        "test_device_registration__03_04_claim_device_to_owner",
        "test_device_registration__04_04_add_device_to_wfh"]

    total_number = len(test_names)

    error_type = []

    error_message = []

    error_http_response_content = []

    splunk_success_event = {
        "event": {
            "schema_version": 1,
            "suite_test_env": "RealData",
            "suite_test_stack": None,
            "suite_test_owner": "WFH_Journey",
            "suite_test_name": "WFH_Printer_Claim_and_Registration",
            "suite_test_status": "passed",
            "cloudID": None,
            "deviceUUID": None,
            "companyId": None,
            "companyTenantID": None,
            "serialNumber": None,
            "unit_tests:": [
                {"name": "test_device_onboarding__01_04_wpp__createWFHPrinter", "status": "passed"},
                {"name": "test_device_onboarding__02_04_jam__registerDeviceInJAM", "status": "passed"},
                {"name": "test_device_registration__03_04_claim_device_to_owner", "status": "passed"},
                {"name": "test_device_registration__04_04_add_device_to_wfh", "status": "passed"}]
        }
    }

    splunk_fail_event = {
        "event": {
            "schema_version": 1,
            "suite_test_env": "RealData",
            "suite_test_stack": None,
            "suite_test_owner": "WFH_Journey",
            "suite_test_name": "WFH_Printer_Claim_and_Registration",
            "suite_test_status": "failed",
            "cloudID": None,
            "deviceUUID": None,
            "companyId": None,
            "companyTenantID": None,
            "serialNumber": None,
            "unit_test_name_failed": None,
            "suite_test_error": {
                "error_type": "",
                "error_message": "",
                "http_method": "",
                "http_request_payload": {},
                "http_request_header": {},
                "http_response_header": {},
                "http_response_content": ""
            }

        }
    }

    def create_splunk_event(self):
        remaining_tests = self.test_names
        left_test_number = len(remaining_tests)
        print("-----------teardown_class called once for the class--------------")
        if left_test_number > 0:
            event = self.splunk_fail_event
            event["event"]["suite_test_stack"] = Param.stack
            event["event"]["unit_test_name_failed"] = remaining_tests[0]
            event["event"]["cloudID"] = Param.device_id
            event["event"]["deviceUUID"] = Param.uuid
            event["event"]["companyId"] = Param.companyId
            event["event"]["companyTenantID"] = Param.companyTenantId
            event["event"]["serialNumber"] = Param.serial_number
            if len(self.error_http_response_content) > 0:
                print("-----------print error--------------")
                print(self.error_type[0])
                print(self.error_message[0])
                print(type(self.error_message[0]))
                print(self.error_http_response_content[0])
                print(type(self.error_http_response_content[0]))
            if len(self.error_type) > 0:
                event["event"]["suite_test_error"]["error_type"] = self.error_type[0]
        else:
            event = self.splunk_success_event
            event["event"]["suite_test_stack"] = Param.stack
            event["event"]["cloudID"] = Param.device_id
            event["event"]["deviceUUID"] = Param.uuid
            event["event"]["companyId"] = Param.companyId
            event["event"]["companyTenantID"] = Param.companyTenantId
            event["event"]["serialNumber"] = Param.serial_number
        print("splunk-event")
        print(event)
        push_splunk_event(event)


def push_splunk_event(event):
    splunk_service.push_suite_test_data(event)
