import json
import os
from config import URLS


def create_json_file(data):
    ado_files_dir = os.environ['ADO_WORK_DIR']
    wfh_json_output_file= os.path.join(ado_files_dir, "jam_wfh_integration_file.json")
    json_file= open(wfh_json_output_file, "w+")
    json_file.write(json.dumps(data))
    json_file.close()
