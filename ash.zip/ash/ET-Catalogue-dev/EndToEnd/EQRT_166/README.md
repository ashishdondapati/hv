# Easy Setup + AFU Hero Flows 
Jira link: https://jira.cso-hp.com/browse/EQTR-166
