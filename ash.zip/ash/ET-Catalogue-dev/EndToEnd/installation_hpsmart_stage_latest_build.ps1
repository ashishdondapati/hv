#
# Copyright 2021 Hewlett-Packard Development Company, L.P.
#
# HP Team EQT Tools
#
# Power shell Script to download and install the latest stage build for Gotham Ultron Win Desktop
#

# Current and Installation Folder Configuration

$installation_folder = $Env:ADO_HPSMART_INSTALL

$Dest   = "\\cscr.hp.com\san\nexus\wip2\cscr\GothamUltron"
$Username = $Env:ADO_HPSMART_USER
$Password = ConvertTo-SecureString $Env:ADO_HPSMART_PWD -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential($Username, $Password)
New-PSDrive -Name T -PSProvider FileSystem -Root $Dest -Credential $mycreds -Persist
Get-PSDrive

# Clear up the old files in the installation folder
Write-Host "Clearing Installation Folder: " $installation_folder " ..." -ForegroundColor Yellow
Set-Location $installation_folder
Get-ChildItem -Path $installation_folder | Remove-Item -Force -Recurse -Confirm:$false
Write-Host "Done Clearing Installation Folder." -ForegroundColor Green

# Pause
Start-Sleep -Seconds 5

# This block of code will be enable as soon the latest folder is available
# Accessing the Gotham Ultron stage latest version from builds repository
Write-Host "Accessing Gotham Ultron Folder: " $installation_folder " ..." -ForegroundColor Yellow
$gotham_ultron_builds_folder = "\\cscr.hp.com\san\nexus\wip2\cscr\GothamUltron\"
$latest_build_folder_name = Get-ChildItem -Path $gotham_ultron_builds_folder -Directory | Sort-Object | Select-Object Name -Last 1
Write-Host "Done Accessing Gotham Ultron Folder: " $installation_folder " ..." -ForegroundColor Green

# Accessing the Gotham Ultron stage version 128.0.3871 from builds repository
# Write-Host "Accessing Gotham Ultron Folder 128.0.3871: " $installation_folder " ..." -ForegroundColor Yellow
# $gotham_ultron_builds_folder = "\\cscr.hp.com\san\nexus\wip2\cscr\GothamUltron\"
# $latest_build_folder_name = "128.0.3871"
# Write-Host "Done Accessing Gotham Ultron Folder 128.0.3871: " $installation_folder " ..." -ForegroundColor Green

# Get Gotham Ultron zip file
Write-Host "Getting Gotham Utron zip file ..." -ForegroundColor Yellow
$latest_build_folder = $gotham_ultron_builds_folder + $latest_build_folder_name.Name + "\"
$hp_smart_stage_file_name = "GothamUltron-" + $latest_build_folder_name.Name + ".zip"
$latest_build_folder_and_file = $latest_build_folder + $hp_smart_stage_file_name
Write-Host "Done Getting Gotham Ultron zip file ..." $latest_build_folder_and_file -ForegroundColor Green

# Pause
Start-Sleep -Seconds 5

# Copy the Gotham Ultron zip file to a local folder
Write-Host "Copying Gotham Utron zip file ..." $latest_build_folder_and_file -ForegroundColor Yellow
Set-Location $latest_build_folder
Copy-Item $latest_build_folder_and_file -Destination $installation_folder
Set-Location $installation_folder
Write-Host "Done Copying Gotham Ultron zip file ..." $installation_folder -ForegroundColor Green

# Pause
Start-Sleep -Seconds 5

# Unzip the Gotham Ultron file to a local installation folder
# $hp_smart_stage_file_name = "C:\dev_env\hpsmart_stage\GothamUltron-128.0.3886.zip"
Write-Host "Unzipping Gotham Utron zip file ..." -ForegroundColor Yellow
Expand-Archive -LiteralPath $hp_smart_stage_file_name -DestinationPath $installation_folder
Write-Host "Done Unzipping Gotham Ultron zip file ..." -ForegroundColor Green

# Pause
Start-Sleep -Seconds 5

Get-PSDrive T | Remove-PSDrive

# Pause
Start-Sleep -Seconds 2

Get-PSDrive

Invoke-Expression -Command $installation_folder'\Install.ps1 -Force'

exit

