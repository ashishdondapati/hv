class DCSError(RuntimeError):
    def __init__(self, _error):
        self.error = _error
        self.message = 'DCS Error: \n\t{} '.format(_error)
