import json


class DCSHTTPError(RuntimeError):
    def __init__(self, _error, _headers, _data, _resp):
        self.error = _error
        self.resp = _resp
        _headers['Authorization'] = 'Hidden'
        _resp['access_token'] = 'Hidden'
        self.message = 'DCS HTTP Error: ' \
                       '\n\t{} ' \
                       '\nDCS HTTP Header: ' \
                       '\n\t{}' \
                       '\nDCS HTTP Request: ' \
                       '\n\tbody = {}' \
                       '\nDCS HTTP Response: ' \
                       '\n\tbody = {}'.format(_error, _headers, json.dumps(_data), _resp.text)
