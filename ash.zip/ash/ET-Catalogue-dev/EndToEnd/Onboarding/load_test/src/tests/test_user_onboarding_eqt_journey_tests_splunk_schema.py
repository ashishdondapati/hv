from src.services import splunk_service
from src.tests.ows_stratus_ci.test_user_onboarding_eqt_journey_tests_param import Param


class SplunkSchema(object):


    def create_splunk_event(self):
        remaining_tests = self.test_names
        left_test_number = len(remaining_tests)
        print("-----------teardown_class called once for the class--------------")
        if left_test_number > 0:
            event = self.splunk_fail_event
            passed_tests_number = self.total_number - left_test_number
            percentage_of_success = passed_tests_number / self.total_number
            event["event"]["suite_test_stack"] = Param.stack
            event["event"]["unit_test_name_failed"] = remaining_tests[0]
            event["event"]["suite_test_percentage_of_sucess"] = "{0:.0%}".format(percentage_of_success)

            if len(self.error_http_response_content) > 0:
                print("-----------print error--------------")
                print(self.error_type[0])
                print(self.error_message[0])
                print(type(self.error_message[0]))
                print(self.error_http_response_content[0])
                print(type(self.error_http_response_content[0]))
            if len(self.error_type) > 0:
                event["event"]["suite_test_error"]["error_type"] = self.error_type[0]

        else:
            event = self.splunk_success_event
            event["event"]["suite_test_stack"] = Param.stack

        print("splunk-event")
        print(event)
        push_splunk_event(event)

    test_names = ['test_user_onboarding__01_14_stratus_authz__get_service_access_token',
                  'test_user_onboarding__02_14_ucde__fetch_ui_extension_info',
                  'test_user_onboarding__03_14_ucde__fetch_ui_infos',
                  'test_user_onboarding__04_14_stratus_authz__exchange_access_token',
                  "test_user_onboarding__05_14_ucde__create_account",
                  "test_user_onboarding__06_14_ucde__fetch_ui_infos",
                  "test_user_onboarding__07_14_ucde__fetch_consents",
                  "test_user_onboarding__08_14_ucde__patch_consents",
                  "test_user_onboarding__09_14_ucde__fetch_ui_infos",
                  "test_user_onboarding__10_14_stratus_authz__exchange_access_token",
                  "test_user_onboarding__11_14_ucde__check_user_account",
                  "test_user_onboarding__12_14_ucde__check_user_consents",
                  "test_user_onboarding__13_14_stratus_authz__introspect_token",
                  "test_user_onboarding__14_14_stratus_user_mgt__read_user_profile"
                  ]

    total_number = len(test_names)

    error_type = []

    error_message = []

    error_http_response_content = []

    splunk_success_event = {
        "event": {
            "suite_test_env": "RealData",
            "suite_test_stack": None,
            "suite_test_owner": "Azure DevOps - OWS Stratus CI Pipelines - EQT Automation",
            "suite_test_name": "User Onboarding: eqt.journey.tests@gmail.com",
            "suite_test_percentage_of_sucess": "100%",
            "suite_test_script_name": "test_user_onboarding_eqt_journey_tests.py",
            "suite_test_status": "success"
        }
    }
    splunk_fail_event = {
        "event": {"suite_test_stack": None,
                  "suite_test_env": "RealData",
                  "suite_test_owner": "Azure DevOps - OWS Stratus CI Pipelines - EQT Automation",
                  "suite_test_name": "User Onboarding: eqt.journey.tests@gmail.com",
                  "suite_test_percentage_of_sucess": None,
                  "suite_test_script_name": "test_user_onboarding_eqt_journey_tests.py",
                  "suite_test_status": "failed",
                  "unit_test_name_failed": None,
                  "suite_test_error": {
                      "error_type": "",
                      "error_message": "",
                      "http_method": "",
                      "http_request_payload": {},
                      "http_request_header": {},
                      "http_response_header": {},
                      "http_response_content": ""
                  }
                  }
    }


def push_splunk_event(event):
    splunk_service.push_suite_test_data(event)
