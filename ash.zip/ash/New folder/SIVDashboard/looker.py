#-*-coding:utf-8-*-

import sys, os, io
import time
import re
import json
import datetime
sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding = 'utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding = 'utf-8')


# from connector.TestrailConn import *
from connector.SQLManager import *
from connector.LookerConn import *

print(sys.getdefaultencoding())

arr_lookID = [375,403,406,402]

# Test
# SIV-C
#lookid_all_issue = 375 #V1
lookid_all_issue = 467 # V3
# for workaround about close date
lookid_all_issue_resolve_date = 463
#lookid_initiative= 406 #V3
lookid_initiative= 469 #V3
#lookid_Epic = 402 #v1
lookid_Epic = 470 # V3
lookid_Epic_linked = 456

schema={}
schema['jv3_projects_base.NAME'] = 'jira_projects_base.NAME'
schema['jv3_issues.KEY'] = 'jira_issues.KEY'
schema['jv3_issues.ISSUE_TYPE'] = 'jira_issues.ISSUE_TYPE'
schema['jv3_issues.SUMMARY'] = 'jira_issues.SUMMARY'
schema['jv3_status.STATUS'] = 'jira_status.STATUS'
schema['jv3_custom_fields_single_select_string_fields.test_milestone_url'] = 'jira_issues.test_milestone_url'
schema['jv3_issue_types.link_type'] = 'jira_ISSUE_LINK.relationship'
schema['jv3_issue_types.related_issue_key'] = 'jira_ISSUE_LINK.RELATED_ISSUE_KEY'
schema['jv3_epic_parent.epi_parent_key'] = 'jira_epic_parent.epi_parent_key'
schema['jv3_projects_base.KEY'] = 'jira_projects_base.KEY'
schema['jv3_issues.status_progress'] = 'jira_issues.status_progress'
schema['jv3_custom_single_select_fields.validation_status'] = 'jira_issues.validation_status'
schema['jv3_investment_types.investment_types'] = 'jira_INVESTMENT_TYPE.INVESTMENT_TYPE'
schema['jv3_custom_single_select_fields.severity'] = 'jira_custom_single_selects.SEVERITY'
schema['jv3_custom_single_select_fields.reproducibility'] = 'jira_custom_single_selects.REPRODUCIBILITY'
schema['jv3_story_parent.story_parent_key'] = 'jira_issues.EPIC_LINK'
schema['jv3_issues.PRIORITY'] = 'jira_priority.PRIORITY'
schema['jv3_issues.CREATED'] = 'jira_issues.created_date'
schema['jv3_issues.RESOLVED'] = 'jira_issues.RESOLVED_DATE_date'
schema['jv3_applicable_products_list.applicable_products_list'] = 'jira_APPLICABLE_PRODUCTS.APPLICABLE_PRODUCTS'
schema['jv3_components_list.components_list'] = 'jira_components_list.COMPONENTS'
schema['jv3_creator.CREATOR'] = 'jira_creator.CREATOR'
schema['jv3_assignee.ASSIGNEE'] = 'jira_assignee.ASSIGNEE'
schema['jv3_issue_links.related_issue_keys'] = 'jv3_issue_links.related_issue_keys'
schema['initiative_id'] = 'initiative_id'
schema['initiative_name'] = 'initiative_name'
schema['epic_id'] = 'epic_id'
schema['epic_name'] = 'epic_name'

# SIV-T
lookid_sivt_Epic = 474 #V3
lookid_sivt_storylist = 473 #V3
lookid_sivt_all_issue = 475 #V3

looker_ini_path = 'connector\looker.ini'

def SQLTest():
    db_ins = SQLManager()
    cs = db_ins.runQuery("select * from sample1;")

    row = cs.fetchone()
    while row:
        data = ""
        for i in row:
            temp = ''
            if type(i) is int:
                temp = str(i)
            else:
                temp = i
            data = data + ' ' + temp
        print(data)
        row = cs.fetchone()

    db_ins.createTable("tempTable")
    db_ins.dropTable("tempTable")

def CheckSppedForAllAPIs():
    looker = LookerConn()

    arr_data = []

    start = time.time()
    print("start to check api time")
    for look_id in arr_lookID:
        print("%d look getting start" % look_id)
        rt = looker.run_look(look_id)
        rt_json = json.loads(rt)
        arr_data.append(rt_json)

    end = time.time()
    print(end-start)

    print("rt count : %d" % len(arr_data) )

# convert json to SQL statement
def generateSQL(jsondata, TABLE_NAME, Mapping=False):
    sqlstatement = ''

    for json_item in jsondata:
        keylist = "("
        valuelist = "("
        firstPair = True
        for key, value in json_item.items():
            #print(key)
            #print(value)
            if not firstPair:
                keylist += ", "
                valuelist += ", "
            firstPair = False
            if Mapping == True:
                keylist += '[%s]' % schema[key]
            else:
                keylist += '[%s]' % key
            if type(value) is (str):
                valuelist += "'" + value.replace("'","''") + "'"
            elif value is None:
                valuelist += 'null'
            else:
                valuelist += str(value)
        keylist += ")"
        valuelist += ")"

        sqlstatement += "INSERT INTO " + TABLE_NAME + " " + keylist + " VALUES " + valuelist + ";\n---end---\n"

    #print(sqlstatement)
    return sqlstatement

# convert JIRA data to HTML format, to display last comment on PowerBI properly.
# Need to install pandoc(https://pandoc.org/installing.html) in database server, before calling this.
def convert_jira_to_html(jira_data):
    #save jira to file
    temp_jira_path = str(time.time()).split('.')[0] + '_jira_temp.txt'
    temp_html_path = temp_jira_path + '.html'
    with open(temp_jira_path, 'wt', encoding='utf8') as f:
        f.write(jira_data)

    #convert to html
    #html_output = pypandoc.convert_file(temp_jira_path,'jira','html')
    #cmd = 'pandoc -s -c %s --metadata title="%s" -f jira %s -o %s' % ('jira.css', 'converted by jira markdown', temp_jira_path, temp_html_path)
    #cmd = 'pandoc -s -c %s -f jira %s -o %s' % ('jira.css', temp_jira_path, temp_html_path)
    cmd = 'pandoc -s -f jira %s -o %s' % ( temp_jira_path, temp_html_path)
    print(cmd)

    os.system(cmd)

    with open(temp_html_path, 'rt', encoding='utf8') as f:
        html_output = f.read()

    #replace color string
    html_output = html_output.replace('<span color="','<span style="color:')
    #insert table css
    html_output = html_output.replace('  </style>', '\n    table, th, td {  border: 1px solid black;}\n  </style>')
    html_output = html_output.replace('○', '&#9675;')
    #define css
    _css = '''
<style>
table {
  border-collapse: collapse;
}
table, th, td {
  border: 1px solid black;
}
</style>
'''

    #remove temp file
    os.remove(temp_jira_path)
    os.remove(temp_html_path)
    #html = _css + os.linesep + html_output
    html = html_output

    return html

# need to pre-define for type of attributes per each column
# Create table with name of looker look
def createTableForAPI(db_ins, looker):
    # db_ins = SQLManager()
    # looker = LookerConn(looker_ini_path)

    ############# SIV-K
    # initiative
    look = looker.get_look(lookid_initiative)
    TABLE_NAME = str(look.title).replace('-','')
    table_qeury = """CREATE TABLE %s(
                [jv3_issues.KEY] varchar(100),
                [jv3_issues.SUMMARY]  nvarchar(1000),
                [jv3_comment.BODY] ntext NULL,
                [jv3_custom_single_select_fields.risk_type] varchar(50) NULL
            );""" % TABLE_NAME
    db_ins.createTable(TABLE_NAME, table_qeury)

    # epic
    look = looker.get_look(lookid_Epic)
    TABLE_NAME = str(look.title).replace('-','')
    table_qeury = """CREATE TABLE %s(
                        [jira_projects_base.NAME] varchar(200),
                        [jira_issues.KEY] varchar(100),
                        [jira_issues.ISSUE_TYPE] varchar(100),
                        [jira_issues.SUMMARY] nvarchar(2000),
                        [jira_status.STATUS] varchar(20) NULL,
                        [jira_issues.test_milestone_url] varchar(200),
                        [jira_ISSUE_LINK.relationship] varchar(20),
                        [jira_ISSUE_LINK.RELATED_ISSUE_KEY] varchar(100),
                        [jira_epic_parent.epi_parent_key] varchar(100) NULL
                    );""" % TABLE_NAME
    db_ins.createTable(TABLE_NAME, table_qeury)

    # all issues
    look = looker.get_look(lookid_all_issue)
    TABLE_NAME = str(look.title).replace('-','')
    table_qeury = """CREATE TABLE %s(
                            [jira_projects_base.KEY] varchar(100),
                            [jira_projects_base.NAME] varchar(200),
                            [jira_issues.ISSUE_TYPE] varchar(100),
                            [jira_issues.KEY] varchar(100),
                            [jira_status.STATUS] varchar(100),
                            [jira_issues.status_progress] varchar(100),
                            [jira_issues.validation_status] varchar(100),
                            [jira_INVESTMENT_TYPE.INVESTMENT_TYPE] nvarchar(100) NULL,
                            [jira_custom_single_selects.SEVERITY] nvarchar(50) NULL,
                            [jira_custom_single_selects.REPRODUCIBILITY] nvarchar(100) NULL,
                            [jira_issues.SUMMARY] nvarchar(2000),
                            [jira_issues.EPIC_LINK] varchar(100),
                            [jira_priority.PRIORITY] varchar(50) NULL,
                            [jira_issues.created_date] date NULL,
                            [jira_issues.RESOLVED_DATE_date] date NULL,
                            [jira_APPLICABLE_PRODUCTS.APPLICABLE_PRODUCTS] varchar(1000) NULL,
                            [jira_components_list.COMPONENTS] varchar(100) NULL,
                            [jira_creator.CREATOR] nvarchar(100),
                            [jira_assignee.ASSIGNEE] nvarchar(50) NULL,
                            [jv3_issue_links.related_issue_keys] nvarchar(50) NULL,
                            [initiative_id] varchar(100),
                            [initiative_name]  nvarchar(1000),
                            [epic_id] varchar(100),
                            [epic_name] nvarchar(1000)
                    );""" % TABLE_NAME
    db_ins.createTable(TABLE_NAME, table_qeury)

    # issue resolve date
    look = looker.get_look(lookid_all_issue_resolve_date)
    TABLE_NAME = str(look.title).replace('-','')
    table_qeury = """CREATE TABLE %s(
                            [jira_projects_base.NAME] varchar(200),
                            [jira_issues.ISSUE_TYPE] varchar(100),
                            [jira_issues.KEY] varchar(100),
                            [jira_status.STATUS] varchar(100),
                            [jira_issues.created_date] date NULL,
                            [jira_issue_resolution_history.RESOLUTION_HIS] varchar(20) NULL,
                            [jira_issue_status_history.STATUS_HIS] varchar(100),
                            [jira_issue_status_history_detail.MOVEIN_TIME] datetime
                    );""" % TABLE_NAME
    db_ins.createTable(TABLE_NAME, table_qeury)

    ############# SIV-T
    # Epic
    look = looker.get_look(lookid_sivt_Epic)
    TABLE_NAME = str(look.title).replace('-','')
    table_qeury = """CREATE TABLE %s(
                [jv3_issues.KEY] varchar(100),
                [jv3_issues.SUMMARY]  nvarchar(1000),
                [jv3_comment.BODY] ntext NULL
            );""" % TABLE_NAME
    db_ins.createTable(TABLE_NAME, table_qeury)

    # Story
    look = looker.get_look(lookid_sivt_storylist)
    TABLE_NAME = str(look.title).replace('-','')
    table_qeury = """CREATE TABLE %s(
                        [jv3_projects_base.NAME] varchar(200),
                        [jv3_issues.KEY] varchar(100),
                        [jv3_issues.ISSUE_TYPE] varchar(100),
                        [jv3_issues.SUMMARY] nvarchar(2000),
                        [jv3_status.STATUS] varchar(20) NULL,
                        [jv3_story_parent.story_parent_key] varchar(20),
                        [jv3_issue_types.RELATED_ISSUE_KEY] varchar(100)
                    );""" % TABLE_NAME
    db_ins.createTable(TABLE_NAME, table_qeury)

    # issues
    look = looker.get_look(lookid_sivt_all_issue)
    TABLE_NAME = str(look.title).replace('-','')
    table_qeury = """CREATE TABLE %s(
                            [jv3_projects_base.KEY] varchar(100),
                            [jv3_projects_base.NAME] varchar(200),
                            [jv3_issues.ISSUE_TYPE] varchar(100),
                            [jv3_issues.KEY] varchar(100),
                            [jv3_status.STATUS] varchar(100),
                            [jv3_issues.status_progress] varchar(100),
                            [jv3_custom_single_select_fields.validation_status] varchar(100),
                            [jv3_custom_single_select_fields.bug_resolution] varchar(100),
                            [jv3_custom_single_select_fields.SEVERITY] nvarchar(50) NULL,
                            [jv3_custom_single_select_fields.REPRODUCIBILITY] nvarchar(100) NULL,
                            [jv3_issues.SUMMARY] nvarchar(2000),
                            [jv3_story_parent.story_parent_key] varchar(100) NULL,
                            [jv3_issues.PRIORITY] varchar(50) NULL,
                            [jv3_issues.CREATED] datetime NULL,
                            [jv3_issues.RESOLVED] datetime NULL,
                            [jv3_applicable_products_list.applicable_products_list] varchar(1000) NULL,
                            [jv3_components_list.components_list] varchar(100) NULL,
                            [jv3_creator.CREATOR] nvarchar(100),
                            [jv3_assignee.ASSIGNEE] nvarchar(50) NULL,
                            [epic_id] varchar(100),
                            [epic_name] nvarchar(1000),
                            [story_id] varchar(100),
                            [story_name]  nvarchar(1000)
                    );""" % TABLE_NAME
    db_ins.createTable(TABLE_NAME, table_qeury)

def main():
    # SQLTest()
    # CheckSppedForAllAPIs()

    start = time.time()

    # initialize
    db_ins = SQLManager()
    looker = LookerConn(looker_ini_path)

    ################ create tables if tables do not exist.
    createTableForAPI(db_ins, looker)
    print("########################################")
    print('finish to create tables')
    print("########################################")

    ################ get initiative
    look = looker.get_look(lookid_initiative)
    # User Looker Look name as DB Table name, but DB cannot include '-'
    TABLE_NAME = str(look.title).replace('-','')
    #keys_list = look.query.fields
    rt = looker.run_look(lookid_initiative)
    jsondata = json.loads(rt)

    # prepared json for initiative data
    init_dict = {}

    for json_item in jsondata:
        key = json_item["jv3_issues.KEY"]
        valus = json_item["jv3_issues.SUMMARY"]

        risk_type = json_item["jv3_custom_single_select_fields.risk_type"]
        if risk_type is None:
            jsondata[jsondata.index(json_item)]["jv3_custom_single_select_fields.risk_type"] = 'None'

        # convert jira md format to html <- move to initiative
        jira_md = json_item["jv3_comment.BODY"]
        if jira_md is not None :
            converted_html = convert_jira_to_html(jira_md)
            # save html data to original json
            jsondata[jsondata.index(json_item)]["jv3_comment.BODY"] = converted_html

        init_dict[key] = valus

    insert_statement = generateSQL(jsondata, TABLE_NAME)
    #print(insert_statement)

    with open('insert_statement_initiative.txt', 'wt', encoding='utf8') as f:
        f.write(insert_statement)

    # delete rows
    delete_statement = 'BEGIN TRAN\nDELETE FROM %s \nCOMMIT TRAN\n' % TABLE_NAME
    db_ins.runQuery(delete_statement)

    # insert rows
    cursor = db_ins.runQuery(insert_statement)

    print("########################################")
    print("finish to get initiative")
    print(time.time()-start)
    print("########################################")
    sys.stdout.flush()

    ############# get epic
    # get epic look info
    look = looker.get_look(lookid_Epic)
    TABLE_NAME = str(look.title).replace('-','')

    # get epic data
    rt = looker.run_look(lookid_Epic)
    jsondata = json.loads(rt)

    #prepared json for epic table
    epic_dict = {}
    issue_list= []

    for json_item in jsondata:
        key = json_item["jv3_issues.KEY"]
        SUMMARY = json_item["jv3_issues.SUMMARY"]
        parent_id = json_item["jv3_epic_parent.epi_parent_key"]

        # mapping initiative
        try:
            initiative_name = init_dict[parent_id]
        except Exception as e:
            pass
        else:
            bug_id = json_item["jv3_issue_types.related_issue_key"]

            if bug_id is None:
                continue
            # Check if bug is already mapped with epic and initiative. if already mapped, update to the latest epic
            elif bug_id in issue_list:
                old_epic_name = epic_dict[bug_id]['epic_name']
                # If intiative of the bug is "WFH" identify the latest  epic with FY<year> <month> in the summary. ex: WFH FY21 April Bugs
                if epic_dict[bug_id]['initiative_id'] == 'HPPKSWQA-51':
                    month_dict = {
                        "march": 3,
                        "april": 4,
                        "may": 5,
                        "june": 6,
                        "fall": 12
                    }
                    old_yr = int(old_epic_name.split()[1][2:])
                    new_yr = int(SUMMARY.split()[1][2:])
                    old_month = old_epic_name.split()[2].casefold()
                    new_month = SUMMARY.split()[2].casefold()
                    # if the year of old mapping is bigger than the year in current json_item continue to next bug
                    if old_yr > new_yr:
                        continue
                    # if the year of old mapping is equal to the year in current json_item check for bigger month else continue to next bug
                    elif old_yr == new_yr:
                        if month_dict[old_month] > month_dict[new_month]:
                            continue
                # If intiative of the bug is not "WFH" identify the latest epic by comparing <year>.<month> format in the summary. ex: POtG 21.03 Bugs
                else:
                    old_milestone_ver = re.findall('\d+\.\d+', old_epic_name)
                    new_milestone_ver = re.findall('\d+\.\d+', SUMMARY)
                    # if <year>.<month> of epic that already mapped is bigger than <year>.<month> in current json_item, continue to next bug else update the epic details
                    if len(old_milestone_ver) > 0 and len(new_milestone_ver) == 0:
                        continue
                    elif len(old_milestone_ver) == 0 and len(new_milestone_ver) > 0:
                        pass
                    elif len(old_milestone_ver) == 0 and len(new_milestone_ver) == 0:
                        # Handle IPx naming in POtG Initiative
                        if int(re.findall('IP\d+', old_epic_name)[0][2:]) > int(re.findall('IP\d+', SUMMARY)[0][2:]):
                            continue
                    elif float(old_milestone_ver[0]) > float(new_milestone_ver[0]):
                        continue

            issue_list.append(bug_id)
            epic_dict[bug_id] = {
                'initiative_id': parent_id,
                'initiative_name': initiative_name,
                'epic_id':key,
                'epic_name':SUMMARY
            }

    insert_statement = generateSQL(jsondata, TABLE_NAME, True)

    with open('insert_statement_epic.txt', 'wt', encoding='utf8') as f:
        f.write(insert_statement)

    #db_ins.dropTable(TABLE_NAME)
    #db_ins.createTable(TABLE_NAME, table_qeury)

    # delete rows
    delete_statement = 'BEGIN TRAN\nDELETE FROM %s \nCOMMIT TRAN\n' % TABLE_NAME
    db_ins.runQuery(delete_statement)

    # If there are too many string, error happen in SQL statement. So send query line by line
    count=0
    for query in insert_statement.split('\n---end---\n'):
        if len(query) <= 10:
            continue
        count+=1
        cs = db_ins.runQuery(query)
    print("########################################")
    print("%s Table insert row count : %d" % (TABLE_NAME, count) )
    print("finish to get Epic")
    print(time.time()-start)
    print("########################################")
    sys.stdout.flush()

    ################ get issues
    look = looker.get_look(lookid_all_issue)
    TABLE_NAME = str(look.title).replace('-','')
    ISSUE_TABLE_NAME = TABLE_NAME
    #keys_list = look.query.fields

    filters: Dict[str, str] = {}
    filters["jv3_issues.CREATED"] = "NOT NULL"
    filters["jv3_issues.ISSUE_TYPE"] = "Bug,Request,Story"
    filters["jv3_issues.KEY"] = ','.join(issue_list)
    print(filters)
    print(len(issue_list))

    rt = looker.run_look_with_filter(lookid_all_issue, filters)
    #rt = looker.run_look(lookid_all_issue)
    jsondata = json.loads(rt)

    #prepared json
    print("Start prepared json for all issues (%d)" % len(jsondata))
    update_jsonlist = list()

    for json_item in jsondata:
        key = json_item["jv3_issues.KEY"]

        try:
            item = epic_dict[key]
        except:
            json_item.update(
                {
                    'initiative_id': 'None',
                    'initiative_name': 'None',
                    'epic_id': 'None',
                    'epic_name': 'None'
                }
            )
        else:
            json_item.update(item)

        update_jsonlist.append(json_item)

    print("finish prepared data")

    insert_statement = generateSQL(update_jsonlist, TABLE_NAME, True)
    with open('insert_statement_issues.txt', 'wt', encoding='utf8') as f:
        f.write(insert_statement)

    # delete rows
    delete_statement = 'BEGIN TRAN\nDELETE FROM %s \nCOMMIT TRAN\n' % TABLE_NAME
    db_ins.runQuery(delete_statement)

    count = 0

    # insert rows
    for query in insert_statement.split('\n---end---\n'):
        if len(query) <= 10:
            continue
        count+=1
        cs = db_ins.runQuery(query)

    print("########################################")
    print("finish to get all issue ")
    print("%s Table insert row count : %d" % (TABLE_NAME, count) )
    print(time.time()-start)
    print("########################################")
    sys.stdout.flush()

    '''
    ################ get issues resolve time
    look = looker.get_look(lookid_all_issue_resolve_date)
    TABLE_NAME = str(look.title).replace('-','')
    #keys_list = look.query.fields
    filters: Dict[str, str] = {}
    #filters["jira_issues.ISSUE_TYPE"] = "Bug"
    filters["jira_status.STATUS"] = 'Closed'
    filters["jira_issue_status_history.STATUS_HIS"] = 'Closed'
    filters["jira_issues.KEY"] = ','.join(issue_list)
    rt = looker.run_look_with_filter(lookid_all_issue_resolve_date, filters)
    jsondata = json.loads(rt)
    insert_statement = generateSQL(jsondata, TABLE_NAME)
    with open('insert_statement_issues_resolve_date.txt', 'wt', encoding='utf8') as f:
        f.write(insert_statement)
    issue_resolve_date = {}
    for json_item in jsondata:
        key = json_item["jira_issues.KEY"]
        timestamp = json_item["jira_issue_status_history_detail.MOVEIN_TIME"]
        try:
            item = issue_resolve_date[key]
        except:
            issue_resolve_date[key] = timestamp # new
        else:
            if item > timestamp:
                issue_resolve_date[key] = item
    #db_ins.dropTable(TABLE_NAME)
    #db_ins.createTable(TABLE_NAME, table_qeury)
    # delete rows
    delete_statement = 'BEGIN TRAN\nDELETE FROM %s \nCOMMIT TRAN\n' % TABLE_NAME
    db_ins.runQuery(delete_statement)
    # insert rows
    for query in insert_statement.split('\n---end---\n'):
        if len(query) <= 10:
            continue
        count+=1
        cs = db_ins.runQuery(query)
    print("%s Table insert row count : %d" % (TABLE_NAME, count) )
    # update database
    sqlstatement = ''
    for key, value in issue_resolve_date.items():
        #value_date = datetime.datetime.strptime(value, '%Y-%m-%d %H:%M:%S.%f').date()
        value_date = datetime.datetime.strptime(value, '%Y-%m-%d %H:%M:%S').date()
        sqlstatement += "update " + ISSUE_TABLE_NAME + " SET [jira_issues.RESOLVED_DATE_date] = '" + str(value_date) + "' where [jira_issues.KEY] = '" + key + "';\n"
    update_statement = "BEGIN TRAN\n" + sqlstatement + "\nCOMMIT TRAN\n"
    with open('update_statement_issues_resolve_date.txt', 'wt', encoding='utf8') as f:
        f.write(update_statement)
    db_ins.runQuery(update_statement)
    #update data - commulated data
    '''

    ################################################### SIV-T #########################################

    # epic - program
    # story - session, milestone of program, linked with program
    # bug - bug, linked with session

    ################ get epic
    look = looker.get_look(lookid_sivt_Epic)
    TABLE_NAME = str(look.title).replace('-','')
    #keys_list = look.query.fields
    rt = looker.run_look(lookid_sivt_Epic)
    jsondata = json.loads(rt)

    # prepared json
    # to put epic / story information to all issue table
    sivtEpic_dict = {}

    for json_item in jsondata:
        key = json_item["jv3_issues.KEY"]
        valus = json_item["jv3_issues.SUMMARY"]

        # convert jira md format to html <- move to epic
        jira_md = json_item["jv3_comment.BODY"]
        if jira_md is not None :
            converted_html = convert_jira_to_html(jira_md)
            # save html data to original json
            jsondata[jsondata.index(json_item)]["jv3_comment.BODY"] = converted_html

        sivtEpic_dict[key] = valus

    insert_statement = generateSQL(jsondata, TABLE_NAME)
    #print(insert_statement)

    with open('insert_statement_sivt_epic.txt', 'wt', encoding='utf8') as f:
        f.write(insert_statement)

    # delete rows
    delete_statement = 'BEGIN TRAN\nDELETE FROM %s \nCOMMIT TRAN\n' % TABLE_NAME
    db_ins.runQuery(delete_statement)

    # insert rows
    cursor = db_ins.runQuery(insert_statement)

    print("########################################")
    print("finish to get epic for SIV-T")
    print(time.time()-start)
    print("########################################")
    sys.stdout.flush()

    ################ get story
    look = looker.get_look(lookid_sivt_storylist)
    TABLE_NAME = str(look.title).replace('-','')

    # get story linked data
    rt = looker.run_look(lookid_sivt_storylist)
    jsondata = json.loads(rt)
    print('count of stories linked issue: %d' % len(jsondata) )

    #prepared json
    story_dict = {}
    issue_list= []

    for json_item in jsondata:
        key = json_item["jv3_issues.KEY"]
        SUMMARY = json_item["jv3_issues.SUMMARY"]
        parent_id = json_item["jv3_story_parent.story_parent_key"]

        # mapping initiative
        try:
            epic_name = sivtEpic_dict[parent_id]
        except Exception as e:
            pass
        else:
            bug_id = json_item["jv3_issue_types.related_issue_key"]
            if bug_id is None:
                continue
            issue_list.append(bug_id)
            story_dict[bug_id] = {
                'epic_id': parent_id,
                'epic_name': epic_name,
                'story_id':key,
                'story_name':SUMMARY
            }

    insert_statement = generateSQL(jsondata, TABLE_NAME)

    with open('insert_statement_sivt_story.txt', 'wt', encoding='utf8') as f:
        f.write(insert_statement)

    # delete rows
    delete_statement = 'BEGIN TRAN\nDELETE FROM %s \nCOMMIT TRAN\n' % TABLE_NAME
    db_ins.runQuery(delete_statement)

    # insert rows
    count=0
    for query in insert_statement.split('\n---end---\n'):
        if len(query) <= 10:
            continue
        count+=1
        cs = db_ins.runQuery(query)
    print("%s Table insert row count : %d" % (TABLE_NAME, count) )

    print("########################################")
    print("finish to get Stories for SIV-T")
    print(time.time()-start)
    print("########################################")
    sys.stdout.flush()

    ################ get siv-t issues
    look = looker.get_look(lookid_sivt_all_issue)
    TABLE_NAME = str(look.title).replace('-','')
    #keys_list = look.query.fields

    print(len(issue_list))
    print(issue_list)

    filters: Dict[str, str] = {}
    filters["jv3_issues.CREATED"] = "NOT NULL"
    filters["jv3_issues.KEY"] = ','.join(issue_list)
    #print(filters)

    rt = looker.run_look_with_filter(lookid_sivt_all_issue , filters)
    jsondata = json.loads(rt)

    #prepared json
    print("Start prepared json for siv-t issues (%d)" % len(jsondata))
    update_jsonlist = list()

    for json_item in jsondata:
        key = json_item["jv3_issues.KEY"]

        try:
            item = story_dict[key]
        except:
            json_item.update(
                {
                    'epic_id': 'None',
                    'epic_name': 'None',
                    'story_id': 'None',
                    'story_name': 'None'
                }
            )
        else:
            json_item.update(item)

        update_jsonlist.append(json_item)

    print("finish prepared data")

    insert_statement = generateSQL(update_jsonlist, TABLE_NAME)
    with open('insert_statement_sivt_issues.txt', 'wt', encoding='utf8') as f:
        f.write(insert_statement)

    # delete rows
    delete_statement = 'BEGIN TRAN\nDELETE FROM %s \nCOMMIT TRAN\n' % TABLE_NAME
    db_ins.runQuery(delete_statement)

    count = 0

    '''
    try:
        #db_ins.runQueries(insert_statement)
        pass
    except Exception as ex:
        print(ex)
    '''

    # insert rows
    for query in insert_statement.split('\n---end---\n'):
        if len(query) <= 10:
            continue
        count+=1
        cs = db_ins.runQuery(query)

    print("########################################")
    print("finish to get all issues for SIV-T")
    print("%s Table insert row count : %d" % (TABLE_NAME, count) )
    print(time.time()-start)
    print("########################################")
    sys.stdout.flush()

    ############### END ################

main()

'''
def download_look(look: models.Look, result_format: str, width: int, height: int):
    """Download specified look as png/jpg"""
    assert look.id
    id = int(look.id)
    task = sdk.create_look_render_task(id, result_format, width, height,)
    if not (task and task.id):
        raise sdk_exceptions.RenderTaskError(
            f"Could not create a render task for '{look.title}'"
        )
    # poll the render task until it completes
    elapsed = 0.0
    delay = 0.5  # wait .5 seconds
    while True:
        poll = sdk.render_task(task.id)
        if poll.status == "failure":
            print(poll)
            raise sdk_exceptions.RenderTaskError(f"Render failed for '{look.title}'")
        elif poll.status == "success":
            break
        time.sleep(delay)
        elapsed += delay
    print(f"Render task completed in {elapsed} seconds")
    result = sdk.render_task_results(task.id)
    filename = f"{look.title}.{result_format}"
    with open(filename, "wb") as f:
        f.write(result)
    print(f"Look saved to '{filename}'")
'''
