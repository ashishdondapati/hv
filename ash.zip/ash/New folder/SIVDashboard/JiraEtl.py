'''
    Jira Incremental update is used to retrieve data from with specified interval of time.
    this application will connect Jira get the required data in given period and
    update them in to SQL server.

    Author: Jayasekaran
    Date : 2/09/2021
'''

from connector.JiraConnectionManger import *
import datetime


def get_latest_jira_issues():
    jira = JiraConnectionManager()
    # get epic from jira --Later
    latest_epic = jira.get_latest_from_jira('Epic')

    # get the story and bugs from Jira
    stories, latest_story = jira.get_latest_from_jira('Story')
    pf_latest_bugs = pd.DataFrame()
    for story in stories:
        pd_bugs = jira.get_latest_from_jira('bugs', story)
        print(pd_bugs.__len__())
        pf_latest_bugs = pd.concat([pf_latest_bugs, pd_bugs])
    # update latest dataframe with old data
    if jira.checkTableExists('APISIVTIssues'):
        dbBugs = jira.selectSQL('APISIVTIssues')
        m_bugs = pd.concat([pf_latest_bugs, dbBugs[~dbBugs['jv3_issues.KEY'].isin(pf_latest_bugs['jv3_issues.KEY'])]])
        # m_bugs = pd.concat([pf_latest_bugs, dbBugs[~dbBugs.index.isin(pf_latest_bugs.index)]])
        # m_bugs.update(dbBugs)
    else:
        m_bugs = pf_latest_bugs

    if jira.checkTableExists('APISIVTEpic'):
        dbEpic = jira.selectSQL('APISIVTEpic')
        m_epic = pd.concat([latest_epic, dbEpic[~dbEpic['jv3_issues.KEY'].isin(latest_epic['jv3_issues.KEY'])]])
    else:
        m_epic = latest_epic

    if jira.checkTableExists('APISIVTStory'):
        dbStory = jira.selectSQL('APISIVTStory')
        m_story = pd.concat([latest_story, dbStory[~dbStory['jv3_issues.KEY'].isin(latest_story['jv3_issues.KEY'])]])
    else:
        m_story = latest_story

    # update SQL database
    jira.submitSQL(m_story, 'APISIVTStory')
    jira.submitSQL(m_bugs, 'APISIVTIssues')
    jira.submitSQL(m_bugs, 'APISIVTEpic')
    print('Jira sync up is completed for current iteration', datetime.datetime.now())

if __name__ == '__main__':
    get_latest_jira_issues()
